import React from 'react';

const Home = () => {
  return (    
      <h1>Welcome to our website!</h1>
  );
};

export default Home;